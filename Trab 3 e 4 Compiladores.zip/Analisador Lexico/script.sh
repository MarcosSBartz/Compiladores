#!/bin/bash

flex lug.l
gcc lex.yy.c
./a.out < teste1.txt
./a.out < teste2.txt
./a.out < teste3.txt
