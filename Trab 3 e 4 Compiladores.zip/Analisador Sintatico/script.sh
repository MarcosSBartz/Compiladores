#!/bin/bash

javacc Lugosi.jj
javac *.java
java Lugosi teste1.lug
java Lugosi teste2.lug
java Lugosi teste3.lug
